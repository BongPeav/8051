/*
AT89S52 HD44780 LCD Programming
*/

#include <reg52.h>
#include <stdio.h>

#define LCD_PORT P2

sbit RS = P2^0;
sbit EN	= P2^1;

void delay_1(unsigned int count){
	while(count>0) count--;
}

void delay_2(unsigned int count){
	while(count>0){
		delay_1(150);
		count--;
	}
}
void lcd_command(char command){
	LCD_PORT=command&0xF0;
	RS=0;
	EN=1;
	delay_1(50);
	EN=0;
	delay_1(50);
	
	LCD_PORT=command<<4;
	RS=0;
	EN=1;
	delay_1(50);
	EN=0;
	delay_1(50);
}

void lcd_data(char _data){
	LCD_PORT=_data&0xF0;
	RS=1;
	EN=1;
	delay_1(50);
	EN=0;
	delay_1(50);
	
	LCD_PORT=_data<<4;
	RS=1;
	EN=1;
	delay_1(50);
	EN=0;
	delay_1(50);
}

void lcd_text(char *text){
	while(*text) lcd_data(*text++);
}

void lcd_xy(char x, char y){
	char cursor[]={0x80,0xC0};
	lcd_command(cursor[y]+x);
}

void lcd_clear(void){
	lcd_command(0x01);
	delay_1(1000);
	lcd_command(0x0C);
}

void lcd_init(void){
	LCD_PORT=0;
	delay_1(1000);
	lcd_command(0x33);
	lcd_command(0x32);
	lcd_command(0x28);
	lcd_command(0x0F);
	lcd_command(0x01);
	delay_1(1000);
	lcd_command(0x06);
}

void main(void){
	int second=0,minute=0,hour=0;
	char msg[16];
	lcd_init();
	lcd_xy(2,0);
	lcd_text("AT89S52 LCD");
	lcd_xy(0,1);
	lcd_text("Programming in C"); 
	delay_2(5000);
	lcd_clear();
	lcd_text("RUNNING TIME:");
	while(1){
		sprintf(msg,"%02d:%02d:%02d",hour,minute,second);
		lcd_xy(0,1);
		lcd_text(msg);
		second++;
		if(second>59){second=0; minute++;}
		if(minute>59) {minute=0; hour++;}
		if(hour>23) {hour=0; }
		delay_2(1000);
	}
}