/*
AT89S52 External Interrupt INT0 and INT1
Progrmming in Keil Using C
*/

#include <REG52.h>

unsigned char press_count=0;

void INT0_ISR(void) interrupt 0
{
	if(press_count>0) press_count--;
}

void INT1_ISR(void) interrupt 2
{
	press_count++;
}


void main(void){
	//INT0 Settings
	IT0 = 1; 	//Select Falling Edge of INT0 pin
	EX0 = 1;	 	//Enable External Interrupt 0
	EA = 1;		//Enable Global Interrupt
	//INT1 Settings
	IT1 = 1;	//Select Falling Edge of INT1 pin
	EX1 = 1;	//Enable External Interrupt 1
	
	while(1){
		P2 = press_count;
	}
	
}