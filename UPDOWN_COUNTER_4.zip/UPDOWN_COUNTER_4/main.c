/*
AT89S52 External Interrupt Multiplexing Display
With Four Digits
*/

#include <REG52.h>

sbit D1 = P1^0;
sbit D2 = P1^1;
sbit D3 = P1^2;
sbit D4 = P1^3;

const unsigned char ssd[16]={0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,
	0x07,0x7F,0x6F,0x77,0x7C,0x39,0x5E,0x79,0x71};

void delay_1_ms(void){
	//1666/8
	unsigned int i = 208;
	while(i>0) i--;
}

void delay_ms(unsigned int count){
	while(count>0){
		delay_1_ms();
		count--;
	}
}

int press_count=0;

void INT0_ISR(void) interrupt 0
{
	if(press_count==0) press_count=9999;
	else press_count--;
}

void INT1_ISR(void) interrupt 2
{
	if(press_count==9999) press_count=0;
	else press_count++;
}


void main(void){
	//INT0 Settings
	IT0 = 1; 	//Select Falling Edge of INT0 pin
	EX0 = 1;	 	//Enable External Interrupt 0
	EA = 1;		//Enable Global Interrupt
	//INT1 Settings
	IT1 = 1;	//Select Falling Edge of INT1 pin
	EX1 = 1;	//Enable External Interrupt 1
	
	while(1){
		P1=0;
		P2 = ssd[press_count/1000];
		D1=1;
		delay_ms(5);
		
		P1=0;
		P2 = ssd[(press_count%1000)/100];
		D2=1;
		delay_ms(5);
		
		P1=0;
		P2 = ssd[(press_count%100)/10];
		D3=1;
		delay_ms(5);
		
		P1=0;
		P2 = ssd[press_count%10];
		D4=1;
		delay_ms(5);
	}
}