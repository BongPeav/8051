
#include "lcd.h"

void delay_1(unsigned int count){
	while(count>0) count--;
}

void delay_2(unsigned int count){
	while(count>0){
		delay_1(150);
		count--;
	}
}
void lcd_command(char command){
	LCD_PORT=command&0xF0;
	RS=0;
	EN=1;
	delay_1(50);
	EN=0;
	delay_1(50);
	
	LCD_PORT=command<<4;
	RS=0;
	EN=1;
	delay_1(50);
	EN=0;
	delay_1(50);
}

void lcd_data(char _data){
	LCD_PORT=_data&0xF0;
	RS=1;
	EN=1;
	delay_1(50);
	EN=0;
	delay_1(50);
	
	LCD_PORT=_data<<4;
	RS=1;
	EN=1;
	delay_1(50);
	EN=0;
	delay_1(50);
}

void lcd_text(char *text){
	while(*text) lcd_data(*text++);
}

char cursor[]={0x80,0xC0};

void lcd_xy(char x, char y){
	
	lcd_command(cursor[y]+x);
}

void lcd_clear(void){
	lcd_command(0x01);
	delay_1(1000);
	lcd_command(0x0C);
}

void lcd_init(void){
	LCD_PORT=0;
	delay_1(1000);
	lcd_command(0x33);
	lcd_command(0x32);
	lcd_command(0x28);
	lcd_command(0x0F);
	lcd_command(0x01);
	delay_1(1000);
	lcd_command(0x06);
}
