
#include <reg52.h>

#define LCD_PORT P2

sbit RS = P2^0;
sbit EN	= P2^1;

void delay_1(unsigned int count);
void delay_2(unsigned int count);
void lcd_command(char command);
void lcd_data(char _data);
void lcd_text(char *text);
void lcd_xy(char x, char y);
void lcd_clear(void);
void lcd_init(void);
