

#include <reg52.h>
#include "lcd.h>

char rcv_data=0;
char char_count=0;

void serial_send(char _data){
	SBUF = _data;
	while(TI==0);
	TI=0;
}

void main(void){
	unsigned int count=0,k=0;
	lcd_init();
	SCON = 0x50;
	TMOD = 0x20;
	TH1 = -3;
	ES = 1;
	EA = 1;
	TR1 = 1;
	
	lcd_xy(2,0);
	lcd_text("AT89S52 UART");
	lcd_xy(0,1);
	lcd_text("Programming in C");
	
	for(count=0;count<100;count++)
		for(k=0;k<5000;k++);
	lcd_clear();
	
	while(1){
		if(rcv_data!=0) {
			lcd_data(rcv_data);
			serial_send(rcv_data);
			rcv_data=0;
			char_count++;	
		}
		lcd_xy(char_count%16,char_count/16);
		if(char_count>32) {
			char_count=0;
			lcd_clear();
		}
	}
}

void serial_IT(void) interrupt 4{
	if(RI == 1){
		RI = 0;
		rcv_data = SBUF;
	}
}